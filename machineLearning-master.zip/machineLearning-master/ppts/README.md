<h1>This is where all the PowerPoint Presentations I use during my Machine Learning tutorials on YouTube will reside</h1>

You can access my Machine Learning playlist videos <a href="https://www.youtube.com/playlist?list=PLlg4M31xJeYa7XcJZWypot8l7R-0E65Ls" target="_blank">here.</a>

Thank you for your interest :)
